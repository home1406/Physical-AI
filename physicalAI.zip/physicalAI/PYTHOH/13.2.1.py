</> python
import RPi.GPIO as GPIO
import time
TRIG = 23
ECHO = 24
GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.output(TRIG, False)
time.sleep(1)
GPIO.output(TRIG, True)
time.sleep(0.00001)
GPIO.output(TRIG, False)
while GPIO.input(ECHO) == 0:
    start = time.time()
while GPIO.input(ECHO) == 1:
    end = time.time()
duration = end - start
distance = duration * 34300 / 2
print("Distance:", distance, "cm")
GPIO.cleanup()