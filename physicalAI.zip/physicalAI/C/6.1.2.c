// 아두이노 보드에 있는 LED는 핀 13에 연결된다:
int led = 13;

// 리셋을 누르면 setup 루틴은 한번만 실행된다:
void setup() {
  // initialize the digital pin as an output.
  pinMode(led, OUTPUT);
}

// loop루틴은 반복하여 계속적으로 실행된다:
void loop() {
  digitalWrite(led, HIGH);   // LED를 켠다. HIGH는 전압레벨
  delay(1000);               // 1초간 대기한다
  digitalWrite(led, LOW);    // 전압을 LOW로 해 LED를 끈다
  delay(1000);               // 1초간 대기한다
}