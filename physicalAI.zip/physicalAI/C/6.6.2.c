void setup()
{
   Serial.begin(9600);
}
void loop()
{
   while (digitalRead(3) == HIGH)
     Serial.println("Released!"); //스위치를 뗌
  
 while (digitalRead(3) == LOW)
     Serial.println("Pressed!"); //스위치를 누름
}