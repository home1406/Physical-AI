#include <Arduino.h>

void initVariant() __attribute__((weak));
void initVariant() { }

int main(void)
{
init();
initVariant();

#if defined(USBCON)
USBDevice.attach();
#endif

setup();  /*==>이곳에서 setup()함수가 호출된다 */
    
for (;;) {
   loop(); /*==>이곳에서 무한 루프가 호출된다*/
   if (serialEventRun) serialEventRun();
}       
return 0;
}